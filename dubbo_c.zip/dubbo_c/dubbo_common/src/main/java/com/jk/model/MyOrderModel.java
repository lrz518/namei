package com.jk.model;

public class MyOrderModel {
    /* 订单实体类
        orderNumber  订单编号
        user_id    用户ID
        addressdataid      收货地址ID
        commodity_img      商品图片
        commodity_name    商品名称
        commodity_price      商品总价
        commodity_number    商品数量
        state               订单状态

    * */
}
